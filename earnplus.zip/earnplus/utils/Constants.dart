class Constants {
  static const String admobAppId = 'ca-app-pub-6040852748531505~2345044036';
  static const String bannerAdUnitId = 'ca-app-pub-6040852748531505/4047355559';
  static const String interstitialAdUnitId = 'ca-app-pub-6040852748531505/4047355559'; // Placeholder
  static const String rewardedAdUnitId = 'ca-app-pub-6040852748531505/4047355559'; // Placeholder
}